
README

Thank you for using EasyGameMaker!

To play the game, open the file "index.html".

The exported game can be played locally or on a server.

If you upload your game to a server, include the "resources" folder together with the "index.html" file.

------------------------------

EasyGameMaker - create your games
https://www.easygamemaker.com

Our YouTube channel:
https://www.youtube.com/@easygamemaker

Our itch.io:
https://easygamemaker.itch.io/

Our sub-reddit:
https://www.reddit.com/r/EasyGameMaker/

